/* ═══════════════════════════════════════════════════════
   demo.js — LoopLayer Live Demo Widget
   Independent module. Edit only this file to change
   the demo behaviour, fields, or CO₂ calculations.
═══════════════════════════════════════════════════════ */

'use strict';

/* ── EPR scheme map (country value → scheme name) ── */
const EPR_SCHEMES = {
  DE: 'Stiftung EAR / Naber',
  FR: 'REFASHION',
  NL: 'Renewi EPR',
  AT: 'ARA EPR',
  BE: 'Fost Plus EPR',
  IT: 'CONAI EPR',
};

/* ── CO₂ factors per material key (tCO₂/tonne, IPCC AR6 WG3 2022) ── */
const CO2_FACTORS = {
  'Cotton offcuts':  1.8,
  'Polyester blend': 3.1,
  'Wool waste':      2.3,
  'Mixed textile':   2.0,
  'Denim scrap':     1.9,
};

/* ── Generate a unique Transaction ID ── */
function txId() {
  return 'LL-' + Date.now().toString(36).toUpperCase()
       + '-' + Math.random().toString(36).substr(2, 4).toUpperCase();
}

/* ── Field validation ── */
function validate() {
  const fields = [
    { id: 'f-co',  errId: 'e-co',  check: v => v.trim().length > 0 },
    { id: 'f-mat', errId: 'e-mat', check: v => v !== '' },
    { id: 'f-kg',  errId: 'e-kg',  check: v => parseFloat(v) > 0 },
    { id: 'f-rec', errId: 'e-rec', check: v => v.trim().length > 0 },
    { id: 'f-cty', errId: 'e-cty', check: v => v !== '' },
  ];
  let ok = true;
  fields.forEach(({ id, errId, check }) => {
    const el  = document.getElementById(id);
    const err = document.getElementById(errId);
    if (!el) return;
    if (!check(el.value)) {
      el.classList.add('err');
      if (err) err.style.display = 'block';
      ok = false;
    } else {
      el.classList.remove('err');
      if (err) err.style.display = 'none';
    }
  });
  return ok;
}

/* ── Set an output field value ── */
function setField(id, val) {
  const el = document.getElementById(id);
  if (!el) return;
  el.textContent = val;
  el.classList.add('pop');
}

/* ── Activate an output document card ── */
function activateDoc(id, label) {
  const status = document.getElementById('st-' + id);
  const card   = document.getElementById('doc-' + id);
  if (status) { status.textContent = label; status.className = 'odoc-status s-ready'; }
  if (card)   card.classList.add('on');
}

/* ── Main generate function ── */
function generateDocs() {
  if (!validate()) return;

  const lang    = window.LL_LANG || 'de';
  const company = document.getElementById('f-co').value.trim();
  const matKey  = document.getElementById('f-mat').value;
  const matLabel = document.querySelector('#f-mat option:checked')?.textContent || matKey;
  const kg      = parseFloat(document.getElementById('f-kg').value);
  const rec     = document.getElementById('f-rec').value.trim();
  const cty     = document.getElementById('f-cty').value;

  const scheme     = EPR_SCHEMES[cty] || cty + ' EPR';
  const co2        = ((CO2_FACTORS[matKey] || 2.0) * kg / 1000).toFixed(2);
  const recycledPct = (82 + Math.floor(Math.random() * 12)) + '%';
  const tx         = txId();

  const co2Suffix = lang === 'de' ? ' tCO₂ vermieden' : ' tCO₂ avoided';
  const pctSuffix = lang === 'de' ? ' recycelt'        : ' recycled';
  const readyLabel = lang === 'de' ? 'Bereit'           : 'Ready';

  const btn = document.getElementById('genbtn');
  const lbl = document.getElementById('genlabel');
  if (btn) btn.disabled = true;
  if (lbl) lbl.textContent = lang === 'de' ? 'Wird erstellt…' : 'Generating…';

  // EPR certificate — 400ms delay
  setTimeout(() => {
    setField('o-co',      company);
    setField('o-mat-epr', matLabel);
    setField('o-kg',      kg.toLocaleString('de-DE') + ' kg');
    setField('o-scheme',  scheme);
    const txEl = document.getElementById('tx-epr');
    if (txEl) txEl.textContent = 'TX ID: ' + tx;
    activateDoc('epr', readyLabel);
  }, 400);

  // CSRD entry — 900ms delay
  setTimeout(() => {
    setField('o-wtype', matLabel);
    setField('o-rrate', recycledPct);
    setField('o-co2',   co2 + co2Suffix);
    setField('o-meth',  'IPCC AR6');
    const txEl = document.getElementById('tx-csrd');
    if (txEl) txEl.textContent = 'TX ID: ' + tx;
    activateDoc('csrd', readyLabel);
  }, 900);

  // DPP — 1400ms delay
  setTimeout(() => {
    setField('o-mat-dpp', matLabel);
    setField('o-rpct',    recycledPct + pctSuffix);
    setField('o-rec-dpp', rec);
    setField('o-schema',  'CIRPASS-2');
    const txEl = document.getElementById('tx-dpp');
    if (txEl) txEl.textContent = 'TX ID: ' + tx;
    activateDoc('dpp', readyLabel);

    if (lbl) lbl.textContent = lang === 'de'
      ? '✓ Erstellt — andere Werte ausprobieren'
      : '✓ Generated — try different values';
    if (btn) btn.disabled = false;
  }, 1400);
}

/* ── Expose to global scope (called from module HTML onclick) ── */
window.generateDocs = generateDocs;

/* ── Clear error styling on user input ── */
function bindErrorClear() {
  document.querySelectorAll('input, select').forEach(el => {
    el.addEventListener('input', () => {
      el.classList.remove('err');
      const err = document.getElementById('e-' + el.id.replace('f-', ''));
      if (err) err.style.display = 'none';
    });
  });
}

/* ── Boot: wait for modules to be in DOM ── */
document.addEventListener('looplayer:ready', bindErrorClear);

/* ── Re-bind after language change (labels may re-render) ── */
document.addEventListener('looplayer:lang', bindErrorClear);
