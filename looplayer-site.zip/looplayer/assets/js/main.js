/* ═══════════════════════════════════════════════════════
   main.js — LoopLayer Core JS
   Handles: module loading · language · ticker · scroll
═══════════════════════════════════════════════════════ */

'use strict';

/* ── 1. MODULE LOADER ─────────────────────────────────
   Fetches all HTML modules in parallel and injects them
   into their placeholder divs, then boots the app.
──────────────────────────────────────────────────────── */
const MODULES = [
  { id: 'mod-nav',           src: 'modules/nav.html'           },
  { id: 'mod-ticker',        src: 'modules/ticker.html'        },
  { id: 'mod-hero',          src: 'modules/hero.html'          },
  { id: 'mod-how-it-works',  src: 'modules/how-it-works.html'  },
  { id: 'mod-three-docs',    src: 'modules/three-docs.html'    },
  { id: 'mod-platform-layers', src: 'modules/platform-layers.html' },
  { id: 'mod-trust',         src: 'modules/trust.html'         },
  { id: 'mod-regulations',   src: 'modules/regulations.html'   },
  { id: 'mod-demo',          src: 'modules/demo.html'          },
  { id: 'mod-template-cta',  src: 'modules/template-cta.html'  },
  { id: 'mod-final-cta',     src: 'modules/final-cta.html'     },
  { id: 'mod-footer',        src: 'modules/footer.html'        },
];

async function loadModule({ id, src }) {
  try {
    const res  = await fetch(src);
    const html = await res.text();
    const el   = document.getElementById(id);
    if (el) el.innerHTML = html;
  } catch (e) {
    console.warn(`[LoopLayer] Could not load module: ${src}`, e);
  }
}

async function init() {
  // Load all modules in parallel
  await Promise.all(MODULES.map(loadModule));

  // After all modules are in the DOM, boot everything
  bootLang();
  bootTicker();
  bootScroll();

  // demo.js listens for this event
  document.dispatchEvent(new Event('looplayer:ready'));
}

document.addEventListener('DOMContentLoaded', init);


/* ── 2. LANGUAGE SYSTEM ───────────────────────────────
   Toggles all [data-de] / [data-en] elements.
   Call setLang('de') or setLang('en') from anywhere.
──────────────────────────────────────────────────────── */
window.LL_LANG = 'de'; // current language — global

window.setLang = function setLang(lang) {
  window.LL_LANG = lang;
  document.documentElement.lang = lang;

  // Toggle nav buttons
  const btnDe = document.getElementById('btn-de');
  const btnEn = document.getElementById('btn-en');
  if (btnDe) btnDe.classList.toggle('on', lang === 'de');
  if (btnEn) btnEn.classList.toggle('on', lang === 'en');

  // Swap all [data-de] / [data-en] innerHTML
  document.querySelectorAll('[data-de]').forEach(el => {
    const val = el.getAttribute('data-' + lang);
    if (val !== null) el.innerHTML = val;
  });

  // Swap placeholders on inputs
  document.querySelectorAll('[data-ph-de]').forEach(el => {
    el.placeholder = el.getAttribute('data-ph-' + lang) || '';
  });

  // Swap select option text
  document.querySelectorAll('select option[data-de]').forEach(opt => {
    const val = opt.getAttribute('data-' + lang);
    if (val) opt.textContent = val;
  });

  // Update waiting status badges in demo
  ['epr', 'csrd', 'dpp'].forEach(id => {
    const el = document.getElementById('st-' + id);
    if (el && el.classList.contains('s-wait')) {
      el.textContent = lang === 'de' ? 'Ausstehend' : 'Waiting';
    }
  });

  // Rebuild ticker in new language
  buildTicker(lang);

  // Let demo.js know the language changed
  document.dispatchEvent(new CustomEvent('looplayer:lang', { detail: { lang } }));
};

function bootLang() {
  // Apply default language (DE) to all elements on first load
  setLang('de');
}


/* ── 3. TICKER ────────────────────────────────────────
   Animated urgency bar. Content is language-aware.
──────────────────────────────────────────────────────── */
const TICKER_CONTENT = {
  de: [
    ['⚠ EPR-Bußgelder werden verhängt', ''],
    ['CSRD / ESRS E5',                   'ab GJ2025 Pflicht'],
    ['Digitaler Produktpass',            'ab 2027 Pflicht'],
    ['6 EU EPR-Systeme',                 'vollständig abgedeckt'],
    ['EPR · CSRD · DPP',                 'eine Transaktion, drei Dokumente'],
    ['Freising, Bayern',                 'looplayer.eu'],
  ],
  en: [
    ['⚠ EPR fines being issued',         ''],
    ['CSRD / ESRS E5',                   'mandatory from FY2025'],
    ['Digital Product Passport',         'mandatory from 2027'],
    ['6 EU EPR schemes',                 'fully covered'],
    ['EPR · CSRD · DPP',                 'one transaction, three documents'],
    ['Freising, Bavaria',                'looplayer.eu'],
  ],
};

function buildTicker(lang) {
  const container = document.getElementById('ticker-inner');
  if (!container) return;
  const items   = TICKER_CONTENT[lang] || TICKER_CONTENT.de;
  const repeated = [...items, ...items]; // doubled for seamless loop
  container.innerHTML = repeated
    .map(([a, b]) =>
      `<span class="ticker-item">
        <span class="ticker-dot"></span>
        ${a}${b ? ` &nbsp;<strong>${b}</strong>` : ''}
      </span>`
    )
    .join('');
}

function bootTicker() {
  buildTicker('de');
}


/* ── 4. SCROLL FADE-IN ────────────────────────────────
   Adds .vis to .fi elements when they enter viewport.
──────────────────────────────────────────────────────── */
function bootScroll() {
  const observer = new IntersectionObserver(entries => {
    entries.forEach(e => {
      if (e.isIntersecting) {
        e.target.classList.add('vis');
        observer.unobserve(e.target);
      }
    });
  }, { threshold: 0.08 });

  document.querySelectorAll('.fi:not(.vis)').forEach(el => observer.observe(el));
}
