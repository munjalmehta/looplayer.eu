# LoopLayer Website

EU Textile Compliance Infrastructure · looplayer.eu

---

## File Structure

```
looplayer/
├── index.html                        ← Shell only — loads all modules
├── .github/
│   └── workflows/
│       └── deploy.yml                ← Auto-deploy to GitHub Pages on push to main
├── assets/
│   ├── css/
│   │   └── styles.css      ← All styles, organised by module section
│   └── js/
│       ├── main.js         ← Module loader · language system · ticker · scroll
│       └── demo.js         ← Live demo widget logic (standalone)
└── modules/
    ├── nav.html            ← Navigation + language toggle
    ├── ticker.html         ← Urgency ticker bar
    ├── hero.html           ← Hero section
    ├── how-it-works.html   ← 4-step process
    ├── three-docs.html     ← EPR / CSRD / DPP document cards
    ├── platform-layers.html← 4-layer platform section
    ├── trust.html          ← Auditor trust + quote + pillars
    ├── regulations.html    ← EPR / CSRD / DPP regulation cards
    ├── demo.html           ← Live demo input form + output
    ├── template-cta.html   ← Free EPR template strip
    ├── final-cta.html      ← Bottom conversion section
    └── footer.html         ← Footer
```

---

## Deploy to GitHub Pages

### One-time setup
1. Create a new GitHub repository
2. Push all files to the `main` branch
3. Go to **Settings → Pages → Source → GitHub Actions**
4. That's it — the workflow runs automatically on every push to `main`

Site goes live at: `https://<your-username>.github.io/<repo-name>/`

No build tools, no npm, no dependencies.

---

## How to Edit a Module

Each section of the site is a separate HTML file in `modules/`.
To change any section:

1. Open the relevant file in `modules/`
2. Edit the HTML
3. Push to `main`
4. Site redeploys automatically (takes ~60 seconds)

**You never need to touch `index.html` unless adding a new module.**

---

## Common Edits

### Change a headline or body copy
Open the relevant module file. All bilingual text uses:
```html
<span data-de="German text" data-en="English text">German text</span>
```
Edit both `data-de` and `data-en` attributes, and the visible default text.

### Add a new nav link
Edit `modules/nav.html` only.

### Change email / contact address
Search for `hello@looplayer.eu` — appears in:
- `modules/template-cta.html`
- `modules/final-cta.html`
- `modules/footer.html`

### Change demo CO₂ factors or EPR schemes
Edit `assets/js/demo.js` — the `CO2_FACTORS` and `EPR_SCHEMES` objects at the top.

### Change ticker content
Edit `assets/js/main.js` — the `TICKER_CONTENT` object.

### Add a new platform layer
Edit `modules/platform-layers.html` only. Copy an existing `.lcard` div and change:
- Class (`l1`–`l4` → add `l5` and matching CSS in `styles.css`)
- Layer number, name, description, bullet points

### Add or remove a module entirely
1. Create/delete the file in `modules/`
2. Add/remove the entry in the `MODULES` array in `assets/js/main.js`
3. Add/remove the placeholder `<div id="mod-..."></div>` in `index.html`

### Change fonts
Edit the Google Fonts `<link>` in `index.html` and update font-family references in `assets/css/styles.css`.

---

## Language System

The site defaults to **German (DE)**. Every user-visible text element has:
```html
data-de="German text"
data-en="English text"
```

The language toggle in `modules/nav.html` calls `setLang('de')` or `setLang('en')`.
The system is defined in `assets/js/main.js` → `setLang()` function.

---

## Local Development

No build step needed. Simply serve with any static file server:

```bash
# Python (built-in)
python3 -m http.server 8080

# Node (if installed)
npx serve .

# VS Code: use the Live Server extension
```

Then open `http://localhost:8080` in your browser.

> **Note:** Opening `index.html` directly as a `file://` URL will not work
> because the module loader uses `fetch()`. Always use a local server.

---

## Contact

hello@looplayer.eu · looplayer.eu · Freising, Bayern
